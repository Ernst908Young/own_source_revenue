<li class="<?= $pa ?>">
            <a href="/backoffice/infowizardtwo/subForm/processedApplication/otd/1">
                <div class="row">
                <div class="col-xs-2 col-lg-2 col-md-2 col-sm-2"> 
                <span class="list-icon">
                    <img src="<?php echo $basePath; ?>/assets/applicant/images/dash-1.png">
                     <img src="<?php echo $basePath; ?>/assets/applicant/images/dashboard-white.png" class="whiteicon">
                </span>
                </div>                
                 <div class="col-xs-10 col-lg-10 col-md-10 col-sm-10">
                Processed Application
                 </div>            
              </div>
            </a>
        </li>
 <li class="<?= $ra ?>">
            
            <a href="/backoffice/investor/serviceprovider/paymentdue">
                  <div class="row">
                <div class="col-xs-2 col-lg-2 col-md-2 col-sm-2"> 
                <span class="list-icon">
                    <img src="<?php echo $basePath; ?>/assets/applicant/images/dash-1.png">
                     <img src="<?php echo $basePath; ?>/assets/applicant/images/dashboard-white.png" class="whiteicon">
                </span>
                </div>                
                 <div class="col-xs-10 col-lg-10 col-md-10 col-sm-10">
                   CTSP Late Fees
                 </div>            
              </div>
            </a>
        </li> 

         <li class="<?= $ra ?>">
            
            <a href="/backoffice/investor/vpd/paymentdue">
                  <div class="row">
                <div class="col-xs-2 col-lg-2 col-md-2 col-sm-2"> 
                <span class="list-icon">
                    <img src="<?php echo $basePath; ?>/assets/applicant/images/dash-1.png">
                     <img src="<?php echo $basePath; ?>/assets/applicant/images/dashboard-white.png" class="whiteicon">
                </span>
                </div>                
                 <div class="col-xs-10 col-lg-10 col-md-10 col-sm-10">
                  Documents Fees
                 </div>            
              </div>
            </a>
        </li>    